ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterServerEvent('steelJob:collectSteel')
AddEventHandler('steelJob:collectSteel', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    xPlayer.addInventoryItem('acier_brute', 1)
end)

RegisterServerEvent('steelJob:processSteel')
AddEventHandler('steelJob:processSteel', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.getInventoryItem('acier_brute').count >= 1 then
        xPlayer.removeInventoryItem('acier_brute', 1)
        xPlayer.addInventoryItem('acier_pure', 1)
    else
        TriggerClientEvent('esx:showNotification', source, "Vous n'avez pas assez d'acier brut à traiter.")
    end
end)

RegisterServerEvent('steelJob:sellSteel')
AddEventHandler('steelJob:sellSteel', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.getInventoryItem('acier_pure').count >= 1 then
        xPlayer.removeInventoryItem('acier_pure', 1)
        local payment = 100 -- Ajuste le montant du paiement selon tes préférences
        xPlayer.addMoney(payment)
        TriggerClientEvent('esx:showNotification', source, "Vous avez vendu de l'acier pur.")
    else
        TriggerClientEvent('esx:showNotification', source, "Vous n'avez pas d'acier pur à vendre.")
    end
end)
