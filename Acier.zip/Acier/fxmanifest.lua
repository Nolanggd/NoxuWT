fx_version 'adamant'
game 'gta5'

author 'NoxuWT'
description 'Script de récolte d’acier'
version '1.0.0'

client_script 'client/main.lua'
server_script 'server/main.lua'

dependencies {
    'mysql-async'
}
