INSERT INTO `items` (`name`, `label`, `limit`) VALUES
	('acier_brute', 'Acier Brute', 150),
	('acier_pure', 'Acier Pure', 250)
;
