local collectionPoint = {x = 98.131, y = -380.878, z = 41.570, radius = 10.0}
local processingPoint = {x = 981.930, y = -1920.212, z = 31.135, radius = 10.0}
local sellingPoint = {x = 1200.0, y = -1500.0, z = 30.0, radius = 10.0}

local isCollecting = false
local isProcessing = false
local isSelling = false

Citizen.CreateThread(function()
    -- Création des blips
    createBlip(collectionPoint, "Récolte d'Acier", 238, 73)
    createBlip(processingPoint, "Traitement D'acier", 238, 73)
    createBlip(sellingPoint, "Vente d'Acier", 238, 73)

    while true do
        Citizen.Wait(0)
        local playerCoords = GetEntityCoords(PlayerPedId())

        -- Point de Récolte
        if GetDistanceBetweenCoords(playerCoords, collectionPoint.x, collectionPoint.y, collectionPoint.z, true) < collectionPoint.radius then
            if not isCollecting then
                DisplayHelpText("Appuyez sur ~INPUT_CONTEXT~ pour commencer à récolter de l'acier brut.")
                if IsControlJustReleased(1, 51) then
                    isCollecting = true
                    Citizen.CreateThread(function()
                        ExecuteCommand('e pickup')
                        while isCollecting do
                            Citizen.Wait(3000)
                            TriggerServerEvent('steelJob:collectSteel')
                            ExecuteCommand('e pickup')
                            if not isCollecting then break end
                        end
                        ClearPedTasks(PlayerPedId())
                    end)
                end
            elseif isCollecting and IsControlJustReleased(1, 51) then
                isCollecting = false
            end
        else
            if isCollecting then
                isCollecting = false
            end
        end

        -- Point de Traitement
        if GetDistanceBetweenCoords(playerCoords, processingPoint.x, processingPoint.y, processingPoint.z, true) < processingPoint.radius then
            if not isProcessing then
                DisplayHelpText("Appuyez sur ~INPUT_CONTEXT~ pour commencer à traiter l'acier brut.")
                if IsControlJustReleased(1, 51) then
                    isProcessing = true
                    Citizen.CreateThread(function()
                        ExecuteCommand('e pickup')
                        while isProcessing do
                            Citizen.Wait(3000)
                            TriggerServerEvent('steelJob:processSteel')
                            ExecuteCommand('e pickup')
                            if not isProcessing then break end
                        end
                        ClearPedTasks(PlayerPedId())
                    end)
                end
            elseif isProcessing and IsControlJustReleased(1, 51) then
                isProcessing = false
            end
        else
            if isProcessing then
                isProcessing = false
            end
        end

        -- Point de Vente
        if GetDistanceBetweenCoords(playerCoords, sellingPoint.x, sellingPoint.y, sellingPoint.z, true) < sellingPoint.radius then
            if not isSelling then
                DisplayHelpText("Appuyez sur ~INPUT_CONTEXT~ pour commencer à vendre l'acier pur.")
                if IsControlJustReleased(1, 51) then
                    isSelling = true
                    Citizen.CreateThread(function()
                        ExecuteCommand('e pickup')
                        while isSelling do
                            Citizen.Wait(3000)
                            TriggerServerEvent('steelJob:sellSteel')
                            ExecuteCommand('e pickup')
                            if not isSelling then break end
                        end
                        ClearPedTasks(PlayerPedId())
                    end)
                end
            elseif isSelling and IsControlJustReleased(1, 51) then
                isSelling = false
            end
        else
            if isSelling then
                isSelling = false
            end
        end
    end
end)

function DisplayHelpText(text)
    SetTextComponentFormat("STRING")
    AddTextComponentString(text)
    DisplayHelpTextFromStringLabel(0, 0, 1, -1)
end

function createBlip(coords, text, sprite, color)
    local blip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(blip, sprite)
    SetBlipDisplay(blip, 4)
    SetBlipScale(blip, 0.8)
    SetBlipColour(blip, color)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(text)
    EndTextCommandSetBlipName(blip)
end
