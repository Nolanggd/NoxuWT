fx_version 'cerulean'
games { 'gta5' }

author 'NoxuWT'
description 'Script de récolte, traitement et vente de pommes'
version '1.0.0'

client_scripts {
    'client.lua'
}

server_scripts {
    '@es_extended/locale.lua',
    'server.lua'
}

dependencies {
    'es_extended'
}
