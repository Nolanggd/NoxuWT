ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) 
    ESX = obj 
end)


local pointsDeRecolte = {
    {x = 2091.31, y = 4836.71, z = 41.76, radius = 20.0},

}

local pointDeTraitement = {x = 200.0, y = -1500.0, z = 30.0, radius = 10.0}
local pointDeVente = {x = 300.0, y = -2000.0, z = 40.0, radius = 10.0}

-- Événement de récolte des pommes
RegisterServerEvent('appleJob:collectApples')
AddEventHandler('appleJob:collectApples', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    xPlayer.addInventoryItem('apple', 1) -- Ajoute une pomme à l'inventaire du joueur
end)

-- Événement de traitement des pommes
RegisterServerEvent('appleJob:processApples')
AddEventHandler('appleJob:processApples', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.getInventoryItem('apple').count >= 1 then
        xPlayer.removeInventoryItem('apple', 1) -- Retire une pomme brute de l'inventaire du joueur
        xPlayer.addInventoryItem('apple_juice', 1) -- Ajoute une pomme transformée (traitée) à l'inventaire du joueur
    else
        TriggerClientEvent('esx:showNotification', source, "Vous n'avez pas assez de pommes à traiter.")
    end
end)

-- Événement de vente des pommes traitées
RegisterServerEvent('appleJob:sellApples')
AddEventHandler('appleJob:sellApples', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.getInventoryItem('apple_juice').count >= 1 then
        xPlayer.removeInventoryItem('apple_juice', 1) -- Retire une pomme traitée de l'inventaire du joueur
        local payment = 1500 -- Ajuste le montant du paiement selon tes préférences
        xPlayer.addMoney(payment) -- Ajoute de l'argent au joueur pour la vente des pommes
        TriggerClientEvent('esx:showNotification', source, "Vous avez vendu une pomme traitée.")
    else
        TriggerClientEvent('esx:showNotification', source, "Vous n'avez pas de pommes traitées à vendre.")
    end
end)
