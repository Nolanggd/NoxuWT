local pointDeRecolte = {x = 2091.31, y = 4836.71, z = 41.76, radius = 20.0}
local pointDeTraitement = {x = 200.0, y = -1500.0, z = 30.0, radius = 10.0}
local pointDeVente = {x = 300.0, y = -2000.0, z = 40.0, radius = 10.0}

local enTrainDeRecolter = false
local enTrainDeTraiter = false
local enTrainDeVendre = false

Citizen.CreateThread(function()
    -- Création des blips
    creerBlip(pointDeRecolte, "Récolte de Pommes", 515, 1)
    creerBlip(pointDeTraitement, "Traitement de Pommes", 499, 1)
    creerBlip(pointDeVente, "Vente de Pommes", 500, 1)

    while true do
        Citizen.Wait(0)
        local coordsJoueur = GetEntityCoords(PlayerPedId())

        -- Point de Récolte
        if GetDistanceBetweenCoords(coordsJoueur, pointDeRecolte.x, pointDeRecolte.y, pointDeRecolte.z, true) < pointDeRecolte.radius then
            if not enTrainDeRecolter then
                AfficherTexteAide("Appuyez sur ~INPUT_CONTEXT~ pour commencer à récolter des pommes.")
                if IsControlJustReleased(1, 51) then
                    enTrainDeRecolter = true
                    ExecuteCommand('e pickup')
                    TriggerEvent('notification', 'Récolte de pommes en cours.', 1) -- À adapter selon votre système de notification
                    Citizen.CreateThread(function()
                        while enTrainDeRecolter do
                            ExecuteCommand('e pickup')
                            Citizen.Wait(2000)
                            TriggerServerEvent('appleJob:collectApples') -- Événement côté serveur pour la récolte des pommes
                            TriggerEvent('notification', 'Vous avez récolté des pommes.', 1) -- Notification pour indiquer que la récolte est terminée
                            if not enTrainDeRecolter then break end
                        end
                    end)
                end
            elseif enTrainDeRecolter and IsControlJustReleased(1, 51) then
                enTrainDeRecolter = false
            end
        else
            if enTrainDeRecolter then
                enTrainDeRecolter = false
            end
        end

        -- Point de Traitement
        if GetDistanceBetweenCoords(coordsJoueur, pointDeTraitement.x, pointDeTraitement.y, pointDeTraitement.z, true) < pointDeTraitement.radius then
            if not enTrainDeTraiter then
                AfficherTexteAide("Appuyez sur ~INPUT_CONTEXT~ pour commencer à transformer les pommes.")
                if IsControlJustReleased(1, 51) then
                    enTrainDeTraiter = true
                    TriggerEvent('notification', 'Transformation de pommes en cours.', 1) -- À adapter selon votre système de notification
                    Citizen.CreateThread(function()
                        while enTrainDeTraiter do
                            Citizen.Wait(3000)
                            TriggerServerEvent('appleJob:processApples') -- Événement côté serveur pour le traitement des pommes
                            TriggerEvent('notification', 'Vous avez transformé les pommes.', 1) -- Notification pour indiquer que le traitement est terminé
                            if not enTrainDeTraiter then break end
                        end
                    end)
                end
            elseif enTrainDeTraiter and IsControlJustReleased(1, 51) then
                enTrainDeTraiter = false
            end
        else
            if enTrainDeTraiter then
                enTrainDeTraiter = false
            end
        end

        -- Point de Vente
        if GetDistanceBetweenCoords(coordsJoueur, pointDeVente.x, pointDeVente.y, pointDeVente.z, true) < pointDeVente.radius then
            if not enTrainDeVendre then
                AfficherTexteAide("Appuyez sur ~INPUT_CONTEXT~ pour commencer à vendre des pommes transformées.")
                if IsControlJustReleased(1, 51) then
                    enTrainDeVendre = true
                    TriggerEvent('notification', 'Vente de pommes en cours.', 1) -- À adapter selon votre système de notification
                    Citizen.CreateThread(function()
                        while enTrainDeVendre do
                            Citizen.Wait(3000)
                            TriggerServerEvent('appleJob:sellApples') -- Événement côté serveur pour la vente des pommes
                            TriggerEvent('notification', 'Vous avez vendu des pommes.', 1) -- Notification pour indiquer que la vente est terminée
                            if not enTrainDeVendre then break end
                        end
                    end)
                end
            elseif enTrainDeVendre and IsControlJustReleased(1, 51) then
                enTrainDeVendre = false
            end
        else
            if enTrainDeVendre then
                enTrainDeVendre = false
            end
        end
    end
end)

function AfficherTexteAide(texte)
    SetTextComponentFormat("STRING")
    AddTextComponentString(texte)
    DisplayHelpTextFromStringLabel(0, 0, 1, -1)
end

function creerBlip(coords, texte, sprite, couleur)
    local blip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(blip, sprite)
    SetBlipDisplay(blip, 4)
    SetBlipScale(blip, 0.8)
    SetBlipColour(blip, couleur)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(texte)
    EndTextCommandSetBlipName(blip)
end
