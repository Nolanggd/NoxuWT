INSERT INTO `items` (`name`, `label`, `limit`) VALUES
	('apple', 'Pomme', 150),
	('aplle_juice', 'Jus de Pomme', 250)
;
